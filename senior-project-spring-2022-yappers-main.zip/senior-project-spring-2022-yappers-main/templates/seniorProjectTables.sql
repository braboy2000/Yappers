
DROP TABLE IF EXISTS friendRequest
DROP TABLE IF EXISTS friends;
DROP TABLE IF EXISTS chatHistory; -- channel and chatHistory both have FK to one another
DROP TABLE IF EXISTS channel;	  -- drop one by right click, go to design, relationship, delete
DROP TABLE IF EXISTS messageSent;
DROP TABLE IF EXISTS communityAdmin;
DROP TABLE IF EXISTS communityUsers;
DROP TABLE IF EXISTS communities;
DROP TABLE IF EXISTS users;

CREATE TABLE users(
	ID INT IDENTITY(1,1),
	userID INT NOT NULL PRIMARY KEY,
	userName varchar(50) NOT NULL,
	passWordd varchar(50) NOT NULL,
	unlimitedChat BIT NOT NULL,
	numOfFriends INT,
	avatarImage VARBINARY(MAX) , -- to store images
	LastLoggedIn DATETIME,
);


CREATE TABLE communities(
	ID INT IDENTITY(1,1),
	communityID INT NOT NULL PRIMARY KEY,
	ownerID INT NOT NULL FOREIGN KEY REFERENCES users(userID)
);

CREATE TABLE communityUsers(
	ID INT IDENTITY(1,1),
	communityID INT NOT NULL, -- PK and FK!!
	userID INT NOT NULL,
	CONSTRAINT FK1 FOREIGN KEY (communityID) REFERENCES communities (communityID),
	CONSTRAINT FK2 FOREIGN KEY (userID) REFERENCES users (userID),
	PRIMARY KEY(communityID, userID)

);

CREATE TABLE communityAdmin(
	ID INT IDENTITY(1,1),
	adminID INT NOT NULL,
	communityID INT NOT NULL
	CONSTRAINT FK3 FOREIGN KEY (adminID) REFERENCES users (userID),
	CONSTRAINT FK4 FOREIGN KEY (communityID) REFERENCES communities (communityID),
	PRIMARY KEY(adminID,communityID),
	status INT -- Higher the # the more power
);


CREATE TABLE messageSent(
	ID INT IDENTITY(1,1),
	messageID INT NOT NULL PRIMARY KEY,
	messageContent TEXT,
	messageDate DATETIME,
	senderID INT NOT NULL FOREIGN KEY REFERENCES users(userID)
);


CREATE TABLE channel(
	ID INT IDENTITY(1,1),
	channelID INT PRIMARY KEY,
	communityID INT NOT NULL FOREIGN KEY REFERENCES communities(communityID),
--	chatID INT NOT NULL FOREIGN KEY REFERENCES chatHistory(chatID) we add this later on!!
);

CREATE TABLE chatHistory(
	ID INT IDENTITY(1,1),
	chatID INT NOT NULL PRIMARY KEY,
	channelID INT NOT NULL FOREIGN KEY REFERENCES channel(channelID),
	messageID INT NOT NULL FOREIGN KEY REFERENCES messageSent(messageID)
);

ALTER TABLE channel ADD chatID INT NOT NULL;
ALTER TABLE channel ADD FOREIGN KEY (chatID) REFERENCES chatHistory(chatID);

CREATE TABLE friends(
	friendID INT IDENTITY(1,1),
	directMessage varchar(100),
	recieverUserName varchar(50), --in back end make sure that the usernmae is in the "users" table
	userID INT NOT NULL,
	CONSTRAINT FK5 FOREIGN KEY (userID) REFERENCES users (userID),
	PRIMARY KEY(userID,friendID)
);

CREATE TABLE friendRequest(
	ID INT IDENTITY(1,1),
	senderID INT,
	recieverID INT,
	CONSTRAINT FK6 FOREIGN KEY (senderID) REFERENCES users (userID),
	CONSTRAINT FK7 FOREIGN KEY (recieverID) REFERENCES users (userID),
	PRIMARY KEY(senderID,recieverID),
	senderUserName VARCHAR(50),
	recieverUserName VARCHAR(50),
	note VARCHAR(100)
);



SELECT * FROM users;
SELECT * FROM communities,communityUsers;
SELECT * FROM communityAdmin;
SELECT * FROM messageSent;
SELECT * FROM channel;
SELECT * FROM chatHistory;
SELECT * FROM friends;
SELECT * FROM friendRequest;


