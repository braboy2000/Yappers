
(async function(){
const tok = localStorage.getItem("token")
console.log("start func")
try{
    const response = await fetch(`/api/fetchcom?token=${tok}`,{
    method: "post",
    headers: {
        'accept': 'aaplication/json'
    }
    });

    const dat = await response.json();
    console.log("info",dat.lis)


    let lz = dat.lis
    let ll = document.getElementById("llist")

    lz.forEach(element => {
    let li = document.createElement("li");
    let a = document.createElement("a")
    a.textContent=`room: ${element}`
    a.href=`http://localhost:5000/ws/${element}`
    li.appendChild(a)
    ll.append(li)
    });
}
catch(err){
    console.log("error: ",err)
}
})();