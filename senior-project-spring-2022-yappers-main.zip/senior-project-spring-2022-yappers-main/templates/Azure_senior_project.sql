CREATE TABLE users(
	userID VARCHAR(50) NOT NULL PRIMARY KEY,
	userName varchar(50) NOT NULL,
	passWordd varchar(50) NOT NULL,
	numOfFriends INT,
	LastLoggedIn TIMESTAMP
);

CREATE TABLE communities (
    communityID VARCHAR(50) NOT NULL,
    ownerID VARCHAR(50) NOT NULL,
    PRIMARY KEY (communityID),
    FOREIGN KEY (ownerID) REFERENCES users(userID),
); 

CREATE TABLE communityUsers(
	communityID VARCHAR(50) NOT NULL, -- PK and FK!! CONSTRAINT FK1 FOREIGN KEY (communityID) REFERENCES communities (communityID),
	userID VARCHAR(50) NOT NULL,	  -- CONSTRAINT FK2 FOREIGN KEY (userID) REFERENCES users (userID),
	PRIMARY KEY(communityID, userID),
    name TEXT NOT NULL;
);
ALTER TABLE communityUsers ADD FOREIGN KEY (communityID) REFERENCES communities(communityID);
ALTER TABLE communityUsers ADD FOREIGN KEY (userID) REFERENCES users(userID);

CREATE TABLE communityAdmin(
	adminID VARCHAR(50) NOT NULL, 		-- CONSTRAINT FK3 FOREIGN KEY (adminID) REFERENCES users (userID),
	communityID VARCHAR(50) NOT NULL,	-- CONSTRAINT FK4 FOREIGN KEY (communityID) REFERENCES communities (communityID),
	PRIMARY KEY(adminID,communityID),
	status INT -- Higher the number the more power
);
ALTER TABLE communityAdmin ADD FOREIGN KEY (adminID) REFERENCES users(userID);
ALTER TABLE communityAdmin ADD FOREIGN KEY (communityID) REFERENCES communities(communityID);

CREATE TABLE messageSent(
	messageID VARCHAR(50) NOT NULL PRIMARY KEY,
	messageContent TEXT,
	messageDate TIMESTAMP,
	communityID varchar(50)  -- NOT NULL FOREIGN KEY REFERENCES users(userID)
);
ALTER TABLE messageSent ADD FOREIGN KEY (senderID) REFERENCES users(userID);
ALTER TABLE messageSent ADD FOREIGN KEY (communityID) REFERENCES communities(communityID);

CREATE TABLE channel(
	channelID VARCHAR(50) PRIMARY KEY,
	communityID VARCHAR(50), -- NOT NULL FOREIGN KEY REFERENCES communities(communityID),
);
ALTER TABLE channel ADD FOREIGN KEY (communityID) REFERENCES communities(communityID);

CREATE TABLE chatHistory(
	chatID VARCHAR(50) NOT NULL PRIMARY KEY,
	channelID VARCHAR(50),  -- NOT NULL FOREIGN KEY REFERENCES channel(channelID),
	messageID VARCHAR(50)  -- NOT NULL FOREIGN KEY REFERENCES messageSent(messageID)
);
ALTER TABLE chatHistory ADD FOREIGN KEY (channelID) REFERENCES channel(channelID);
ALTER TABLE chatHistory ADD FOREIGN KEY (messageID) REFERENCES messageSent(messageID);

CREATE TABLE friends(
	friendID VARCHAR(50),
	userID VARCHAR(50),			  -- CONSTRAINT FK5 FOREIGN KEY (userID) REFERENCES users (userID),
	directMessage TEXT,
	recieverUserName varchar(50), -- in back end make sure that the usernmae is in the "users" table didnt make username as PK in users table
	PRIMARY KEY(userID,friendID)
);
ALTER TABLE friends ADD FOREIGN KEY (userID) REFERENCES users(userID);

CREATE TABLE friendRequest(
	senderID VARCHAR(50),	-- CONSTRAINT FK6 FOREIGN KEY (senderID) REFERENCES users (userID),
	recieverID VARCHAR(50),	-- CONSTRAINT FK7 FOREIGN KEY (recieverID) REFERENCES users (userID),
	PRIMARY KEY(senderID,recieverID),
	senderUserName VARCHAR(50),
	recieverUserName VARCHAR(50),
	note VARCHAR(100)
);
ALTER TABLE friendRequest ADD FOREIGN KEY (senderID) REFERENCES users(userID);
ALTER TABLE friendRequest ADD FOREIGN KEY (recieverID) REFERENCES users(userID);


 INSERT INTO users VALUES
('999999999','mama123','yeepee32',1,'2007-05-03 00:00:00')
('999999998','HairyPoppins','ilikeice34',0,'2022-04-10 13:12:22'),
('999999997','cute.as.ducks','password123',2,'2022-03-04 15:35:12'),
('999999996','averagestudent','111111',1,'2022-10-03 18:03:48'),
('999999995','YellowSnowman','qwerty',0,'2023-02-21 20:16:54'),
('999999994','username_copied','love',0,'2022-05-11 23:31:30')
;

INSERT INTO communities VALUES
('888888888','999999999'),
('888888887','999999998'),
('888888886','999999997'),
('888888885','999999996'),
('888888884','999999995'),
('888888883','999999994')
;

INSERT INTO communityUsers VALUES
('888888888','999999999'),
('888888887','999999998'),
('888888886','999999997'),
('888888885','999999996'),
('888888884','999999995'),
('888888883','999999994')
;

INSERT INTO communityAdmin VALUES
('999999999','888888888',2),
('999999998','888888887',1),
('999999997','888888886',3),
('999999996','888888885',4),
('999999995','888888884',1),
('999999994','888888883',5)
;

INSERT INTO messageSent VALUES
('777777777','Have you ever been late a day in your life?','2022/06/12 04:40:51','999999999'),
('777777776','You dont have to make a big deal out of it','2022/11/30 22:52:45','999999998'),
('777777775','Tom took a big breath and blew out the candles.','2022/10/11 11:23:51','999999997'),
('777777774','Good morning!','2023/02/17 23:23:28','999999996'),
('777777773','Stand up and catch that ball!','2022/10/09 07:04:00','999999995'),
('777777772','Get your act together!','2022/08/25 08:01:05','999999994')
;

INSERT INTO channel VALUES
('666666666','888888888'),
('666666665','888888887'),
('666666664','888888886'),
('666666663','888888885'),
('666666662','888888884'),
('666666661','888888883') --manually place chatID into this table
;

INSERT INTO chatHistory VALUES
('555555555','666666666','777777777'),
('555555554','666666665','777777776'),
('555555553','666666664','777777775'),
('555555552','666666663','777777774'),
('555555551','666666662','777777773'),
('555555550','666666661','777777772')
;

INSERT INTO friends VALUES
('444444444','999999999','I need friend!!','cute.as.ducks'),
('444444443','999999997','Please be my friend!!','mama123'),
('444444442','999999997','Will You be my friend? possibly for all of eternity?','averagestudent'),
('444444441','999999996','I want to be more than friends!!','cute.as.ducks'),
('444444440','999999995','I am not a creep..I just want to be your friend',NULL),
('444444439','999999994','My Friends are scary..',NULL)
;

INSERT INTO friendRequest VALUES
('999999994','999999999','username_copied','mama123','Hello beautiful'),
('999999995','999999997','YellowSnowman','cute.as.ducks','hello hello hello'),
('999999996','999999995','averagestudent','cute.as.ducks','are u still there?'),
('999999997','999999998','cute.as.ducks','mama123','do you remember from chemistry class?'),
('999999998','999999995','HairyPoppins','YellowSnowman','Wanna hang out sometimes'),
('999999999','999999994','mama123','username_copied','Meet me by dollar tree ASAP')
;

select * FROM users where userID = '999999999';
-- DELETE FROM users WHERE userName = 'mama123';

SELECT username FROM users WHERE username = 'mama123'
SELECT messageContent FROM messageSent WHERE communityID ='888888883'
SELECT username, passWordd FROM users WHERE username = 'Mr.awesome' AND passWordd = 'noooo!!!'


