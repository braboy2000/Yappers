from fastapi import FastAPI, Request, WebSocket, HTTPException, Depends, APIRouter
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
import fastapi.security
import APIhelper
import asyncpg
import uuid


oauth2scheme = fastapi.security.OAuth2PasswordBearer(tokenUrl="/api/token")
router = APIRouter()

pgcon = APIhelper.Pgsql()

pg_connection_url_string = ""
@router.on_event("startup")
async def startup_event():
    print("starting up from fast")
    pgcon.conn = await asyncpg.connect(pg_connection_url_string)


@router.post("/api/register")
async def api_register(form_data: fastapi.security.OAuth2PasswordRequestForm = Depends() ):
    '''
    this is the method that will check if an account has been made
    if no account has been made, then we will create one
    '''
    db_user = await pgcon.username_exist(username=form_data.username)
    print(db_user)
    if db_user:
        raise HTTPException(status_code=400,detail="username already in use")

    await pgcon.create_login(username=form_data.username,password=form_data.password)
    token = await pgcon.get_current_users(username=form_data.username,password=form_data.password)
    # return {"access_token": form_data.username + "token"} #create function that makes a token?
    return {"access_token": token} #create function that makes a token?

@router.post("/api/token")
async def generate_token(form_data: fastapi.security.OAuth2PasswordRequestForm = Depends() ):
    print(form_data.username)
    user = await pgcon.validate_login(username=form_data.username, password=form_data.password)
    # print(user)
    
    if not user:
        raise HTTPException(status_code=401, detail="Invalid login")
    
    token = await pgcon.get_current_users(username=form_data.username,password=form_data.password)
    # return {"access_token": form_data.username + "token"} #create function that makes a token?
    return {"access_token": token} #create function that makes a token?


@router.post("/api/get_communitymessages")
async def get_communitymessages(communityid):
    x = await pgcon.get_messages(communityID=communityid)
    # print(x)
    return {"messages":x}


@router.post("/api/create_community")
async def create_community(communityname: str, user: str):
    result = await pgcon.create_community(communityID=communityname,userID=user)
    return result

@router.post("/api/join_community")
async def join_community(user:str, community:str):
    result = await pgcon.join_community(communityID=community, userID=user)
    return result


@router.post("/api/fetchcom") #fetch community, current uses userID change it to token
async def fetch(token:str):
    # listofservers[token]
    result = await pgcon.list_user_community(token)
    return {"list": result}

ws_dictionary = {}
@router.websocket("/ws/{communityID}") # establishes the websocket functionality
async def websocket_endpoint(websocket: WebSocket, communityID):
    #add in verify if user is in community

    await websocket.accept()

    #change to publish subscribe 
    x = await pgcon.communityID_exist(communityID)
    print(x)
    if not x: #if the community does not exist wont create a connection
        print("does not exist")
        return


    ws_dictionary[communityID] = []
        
    ws_dictionary[communityID].append(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            for all in ws_dictionary[communityID]:
                await all.send_text(data=data)
                await pgcon.insert_messages(message=data,communityID=communityID) # closes connection for some reason
                print(data)
                
    except:
        ws_dictionary[communityID].remove(websocket)