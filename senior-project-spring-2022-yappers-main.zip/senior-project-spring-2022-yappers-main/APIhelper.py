# import psycopg, secrets, uuid, time
# from psycopg.rows import dict_row
import uuid
import asyncpg
from datetime import datetime

pg_connection_url_string = ""

class Pgsql():
  
    async def validate_login(self,username: str, password: str) -> bool:
        '''
        this function is to validate the login of the user with the information stored in the sql database.
        it takes in the username and password and then does a SQL query to see if the username is stored
        once we get the results back we see if its None or if there is a matching result, returns True or False
        '''
        # row = await self.conn.fetchrow("SELECT username, pass FROM userinfo WHERE username = $1 AND pass = $2" , username, password)
        row = await self.conn.fetchrow("SELECT username, passwordd FROM users WHERE username = $1 AND passwordd = $2" , username, password)
        if row == None:
            print('Given None')
            return False
        # await self.conn.close()
        return bool(username == row['username'] and password == row['passwordd'])
    
 
    async def create_login(self,username: str, password: str) -> bool:
        '''
        this function is so that users can create their account and it will be saved onto a SQL database.
        the user will then be able to login after this function is completed. 
        '''
        dateTimeNow = datetime.now()
        num_of_friends = 0

        # self.conn = await asyncpg.connect(pg_connection_url_string)
        async with self.conn.transaction():
          
            await self.conn.execute("INSERT INTO users VALUES ($1,$2,$3,$4,$5)",uuid.uuid4().hex, username, password, num_of_friends, dateTimeNow)
            return True
        

    async def get_current_users(self,username, password):
        # current_users = await self.conn.fetch('SELECT userName, userID FROM users')
        # current_users = await self.conn.fetchval('SELECT userID FROM users where username = $1 and PASS = $2',username,password)
        current_users = await self.conn.fetchval('SELECT userID FROM users where username = $1 and passwordd = $2',username,password)
        # await self.conn.close()
        return current_users # i think return is a dict but we'll see

    async def get_messages(self,communityID: str) -> list:
        # self.conn = await asyncpg.connect("postgresql://postgres:password@seniorproj.ced0b9crvx68.us-east-1.rds.amazonaws.com:5432/seniorProj")
        try:
            get_messges = await self.conn.fetch("SELECT messageContent FROM messageSent WHERE communityID = $1",communityID)
            # await self.conn.close()
            # return get_messges # i think return is a dict but we'll see
            return [x["messagecontent"] for x in get_messges]
        except NameError:
            print(NameError)
      

    async def delete_login(self, username: str,password: str):
        '''
        this function is pretty straight forward and will delete the account from the database when request to do so by the user 
        '''
        await self.conn.execute("DELETE FROM userinfo WHERE username = $1",username)
        return
    

    async def username_exist(self,username: str) -> bool:
        '''
        this functions is to get a username from the table and to make sure that it exists so that others can't have the same username.
        '''
        result = await self.conn.fetchval("SELECT username FROM users WHERE username = $1",username)

        return result == username

    async def userID_exist(self,userID: str) -> bool:
        result = await self.conn.fetchval("SELECT userID FROM users WHERE userID = $1",userID)

        return result == userID

    async def channelID_exist(self,channelID: str) -> bool:
        result = await self.conn.fetchval("SELECT channelID FROM users WHERE channelID = $1",channelID)
        return result == channelID

    async def communityID_exist(self,communityID: str) -> bool:
        # self.conn = await asyncpg.connect(pg_connection_url_string)
        result = await self.conn.fetchval("SELECT communityID FROM communities WHERE communityID = $1",communityID)
        # result = await self.conn.fetchval("SELECT communityID FROM comms WHERE communityID = $1",communityID)
        #maybe make it so that it checks it all from communityusers and if doesnt exist it makes it?
        # await self.conn.close()
        return result == communityID
    
    async def list_communityID(self):
        self.conn = await asyncpg.connect("postgresql://postgres:password@seniorproj.ced0b9crvx68.us-east-1.rds.amazonaws.com:5432/seniorProj")
        # result = await self.conn.fetch("SELECT communityID FROM communities")

        result = await self.conn.fetch("SELECT communityID FROM communityusers")
        # result = await self.conn.fetch("SELECT communityid FROM commsusers")
        # await self.conn.close()
        data = [dict(row) for row in result]
        return data
        


    async def insert_messages(self,message: str,communityID) -> None:
        # self.conn = await asyncpg.connect(pg_connection_url_string)
        dateTimeNow = datetime.now()

        await self.conn.execute("INSERT INTO messageSent VALUES($1,$2,$3,$4)",uuid.uuid4().hex, message, dateTimeNow, communityID)
        # await self.conn.execute("INSERT INTO msgsent VALUES($1,$2,$3,$4)",uuid.uuid4().hex, message, dateTimeNow, communityID)
        # return 1

    async def join_community(self,communityID,userID)-> None:
        self.conn = await asyncpg.connect("postgresql://postgres:password@seniorproj.ced0b9crvx68.us-east-1.rds.amazonaws.com:5432/seniorProj")
        try:
            await self.conn.execute("INSERT INTO communityusers VALUES($1,$2,$3)",communityID,userID,None)
            # print("worked")
            return True
        except:
            print("failed")
            return False

    async def list_user_community(self,userID):
        self.conn = await asyncpg.connect("postgresql://postgres:password@seniorproj.ced0b9crvx68.us-east-1.rds.amazonaws.com:5432/seniorProj")
        result = await self.conn.fetch("SELECT communityID FROM communityusers WHERE userid = $1",userID)
        # result = await self.conn.fetch("SELECT communityID FROM commsusers WHERE usertoken = $1",usertoken)
        # return result
        return [x["communityid"] for x in result]
    
    async def create_community(self,communityID,userID):
        self.conn = await asyncpg.connect("postgresql://postgres:password@seniorproj.ced0b9crvx68.us-east-1.rds.amazonaws.com:5432/seniorProj")
        try:
            await self.conn.execute("INSERT INTO communities VALUES($1,$2,$3)",communityID,userID,None)
            await self.conn.execute("INSERT INTO communityusers VALUES($1,$2,$3)",communityID,userID,None)
            return True
        except:
            return False

async def main():
    # conn = await asyncpg.connect(pg_connection_url_string)

    # x = await username_exist(conn,"mama123")
    # x = await get_current_users(conn)
    # x = await create_community(conn,'999999999',"My boyzz")
    # x = await create_login(conn,"Mr.awesome", "noooo!!!")
    # x = await validate_login(conn,"Mr.awesom", "noooo!!!")
    print("started")
    co = Pgsql()
    x = await co.create_community("c","c0d331dafa22450abe14fc7149baf8eb")
    # x = await co.list_user_community("51293649e62f48b697c653458e079198")

    # x = await co.join_community(communityID="p",userID="2bf55aedac114b37a6e21a3ef0e44282")

    # x =  await co.get_messages("888888883")
    # x =  await co.get_messages("1")
    # for i in x:
        # print(i['messagecontent'])
        # print(i)
    print(f'----------------------------information: {x}-------------------------------------------')

    # x = await co.insert_messages(message='hello there',communityID='1')
    # x = await co.username_exist(username='gxg')
    # x = await co.create_community('999999999','lolxx')
    # x = await co.list_communityID()
    # x = await co.communityID_exist('0')
    # print(x)

    # y = await co.get_current_users()
    # print()
    # print()
    # print(y)
 
if __name__ == "__main__":
    # asyncio.run(main())
    print("hello")