from fastapi import FastAPI, Request, WebSocket, HTTPException, Depends
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import uvicorn
import Fast
import APIhelper

app = FastAPI()
app.mount(
    "/static",
    StaticFiles(directory=Path(__file__).parent.absolute() / "static"),
    name="static",
)

app.include_router(
Fast.router
)

pgcon = APIhelper.Pgsql()


templates = Jinja2Templates(directory="templates")

@app.get("/")
async def root():
    response = RedirectResponse(url='/login')
    return response


@app.get("/login")
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request":request})

@app.get("/register")
async def register_page():
    return "register page"

@app.get("/main")
async def main_page(request:Request):
    return templates.TemplateResponse("mainpage.html",{"request":request})

@app.get("/ws/{communityID}", response_class=HTMLResponse)
async def websocket_page(request: Request, communityID: str):
    #add in verify if user is in community
    #https://fastapi.tiangolo.com/advanced/templates/
    return templates.TemplateResponse("websocket.html", {"request":request, "communityID" : communityID})


if __name__ == "__main__":
    currhost = "localhost"
    uvicorn.run("Fastmain:app",host=currhost,port=5000)
