# senior-project-spring-2022-yappers
senior-project-spring-2022-yappers created by GitHub Classroom \
Discord replica <br>
In this project we are are attempting to create a chat platform similar to discord and slack with websocket functionality. We will be using fastAPI to create the API methods. 
Addiotnally, we plan to use electronjs to create the frontend and create an executable for those that wish to use that. \
http://18.208.247.189:5000/login   (will expire after may 8, 2022 but can be ran locally if project is downloaded)

Project propentents
+ FastAPI (API methods, WebSocket functionality)
+ Jinja (Frontend for user interface)
+ AWS RDS for PostgreSQL server
<!--hello-->
creators
+ Julian - j_mata4@u.pacific.edu
+ Shan - b_raboy@u.pacific.edu
+ Brandon - b_raboy@u.pacific.edu






[Gnatt Chart Link](https://onedrive.live.com/edit.aspx?resid=F25EBAE357C7F37C!4312&ithint=file%2cxlsx&authkey=!AL1TpO4FxOehCZk)
[Trello Link Scrum Chart](https://trello.com/b/0aeByF9e/oraganizing)


<p align="center">
  Schema
</p>

![image](https://user-images.githubusercontent.com/46388383/155431828-182bbabc-995a-4b86-95b9-72c88a3e5c14.png)
<br>

![image](https://user-images.githubusercontent.com/46388383/158079234-8d3c307d-9a13-43a2-896f-c1154c340182.png)

![](media/schemaPic.jpg)
<p align="center">
  ***Weekly Stand up meeting with profressor -- Every Wednesday at 6 pm via Zoom***
</p>

